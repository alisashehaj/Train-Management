<div class="splash-footer">
  &copy; <?php echo date('Y'); ?>
  Online Railway Reservation System | Developed By <a href="https://sixhei-tartari.vercel.app/" target="_blank">Sixhei Tartari</a>
</div>