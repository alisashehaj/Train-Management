<div class="splash-footer">
    &copy; 2019 - <?php echo date ('Y');?>
    Online Railway Reservation System | Developed By Martin Mbithi Nzilani
</div>
